//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 23/03/18.
//  Copyright © 2018 RenataFaria. All rights reserved.
//
//#-end-hidden-code


import PlaygroundSupport
let viewController = ViewController.instantiateFromStoryboard()
PlaygroundPage.current.liveView = viewController
