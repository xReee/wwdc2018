//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 23/03/18.
//  Copyright © 2018 RenataFaria. All rights reserved.
//
//#-end-hidden-code
/*:
 ## What is  'Voice Over'?
 In this page, I hope to teach you what's VoiceOver and how to use it.\
 If you have read the previous page, probably you noticed that Apple have an interface reader, named VoiceOver. You don't have to implement that in your code because it's a feature of iOS, but it's highly recommended that you configure your app, so it will work as you intended.
 
 "Cool! But... how can I do it?"
 
 I will tell you soon, but before I want to show you this app that's running in your LiveView. I think you've noticed that when you open this page you heard something saying "image: photo from airplane window", this is a simulation of VoiceOver reading an accessible app. Now, try to touch in these views, my simulation will read all for you, as Voice Over will do in you app soon.
 
 [please click here to go to the next page.](@next)

 */
//#-hidden-code
//#-code-completion(everything, hide)




//#-end-hidden-code
