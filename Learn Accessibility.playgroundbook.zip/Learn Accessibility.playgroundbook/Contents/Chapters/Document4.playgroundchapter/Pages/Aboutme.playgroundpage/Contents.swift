//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 23/03/18.
//  Copyright © 2018 RenataFaria. All rights reserved.
//
//#-end-hidden-code
//#-hidden-code
//#-end-hidden-code
/*:
 # Renata Faria Gomes
 ![myPhoto](profile.jpg)
 ## 21 years old
 ## Fortaleza - Ceará - Brazil
 ## Current student of Bachelor degree in Digital Systems and Media in Federal University of Ceará
 ## 2016/2017 intern at Apple Developer Academy - Fortaleza
 \
 Check this code in my GitHub: xReee
 */










