//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 23/03/18.
//  Copyright © 2018 RenataFaria. All rights reserved.
//
//#-end-hidden-code
//#-hidden-code
//#-end-hidden-code
/*:
 ## Review
 You have finishided this playground!
 Thank you a lot and I'm hoping you apply this knowledge in your apps.
 Before I go, I just want to review all things that we learnt
 
 * Callout(Interacting with VoiceOver):
 - Tap any view to hear the accessible label of it
 - Swipe to the left or right to navigate
 - Tap twice to activate a button or an activatable view
 
 * Callout(Making your app accessible):
 - Configure the accessibility label in storyboard using the identity inspector
 - Configure the accessibility label in code using the propriety "accessibilityLabel"

 That's it!\
 Bye and thank you again!\
 [Click here to know more about me.](@next)
 */










