//
//  NotificationCenterStrings.swift
//  TesteWWDC18
//
//  Created by Renata on 19/03/18.
//  Copyright © 2018 Renata. All rights reserved.
//

import Foundation

let resetViewKey =  "WWWDC18.renata.pleaseResetMyViews" // reseting my views status -> is selected to false and border to zero


